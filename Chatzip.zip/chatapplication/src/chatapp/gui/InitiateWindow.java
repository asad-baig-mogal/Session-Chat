package chatapp.gui;

import chatapp.backend.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class InitiateWindow implements ActionListener{

	JFrame frame1;
    JLabel label1;
    JLabel label2;
    JLabel label3;
    JPanel panel1;
    JButton button1;
    JFrame tempFrame;
    static String code;
    public JFrame initiate(JFrame frame)
    {
    	tempFrame = frame;
    	tempFrame.dispose();
       frame1=new JFrame("Session Chat");
       frame1.setLayout(new GridLayout(0,1));
       frame1.setLocationRelativeTo(null);
       frame1.setResizable(false);
       frame1.setIconImage(Toolkit.getDefaultToolkit().getImage("d:/sessionchat/gui/OIP.jpg"));
       
       
        panel1=new JPanel();
        panel1.setBackground(Color.white);
        panel1.setBorder(BorderFactory.createEmptyBorder(100,100,100,100));
        panel1.setLayout(new GridLayout(0,1,0,10));

        label1=new JLabel();
        label1.setFont(new Font("Calibri",Font.BOLD,20));
        label1.setText("Session Code");
       

        
        label2=new JLabel();
        label2.setFont(new Font("Arial Black",Font.BOLD,30));
        String secretcode=new SessionCodeGenerator().code();
        code = secretcode;
        
         SecretCodeStore obj=new SecretCodeStore();
        obj.storekey(secretcode);
        label2.setText(secretcode);
        label2.setForeground(new Color(0, 102, 102));

        label3=new JLabel();
        label3.setFont(new Font("Calibri",Font.BOLD,15));
        label3.setText("Invite others to the session by sharing this code");
        
        button1 = new JButton("Join Session Chat");
        button1.setBackground(new Color(33,182,168));
        button1.setActionCommand("Join");
        button1.addActionListener(this);
        
        
        panel1.add(label1);
        panel1.add(label2);
        panel1.add(label3);
        panel1.add(button1);

        frame1.add(panel1);
        centerLocation();
        frame1.pack();
        frame1.setVisible(true);
        return frame1;
    }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String actioncommand=e.getActionCommand();
	   
	      if(actioncommand.equals("Join"))
	      {
	    	  JoinWindow.code = code;
	    	  new JoinWindow().join(new JFrame());
	    	  
	    	  frame1.dispose();
	      }
		
	}
	
	 public void centerLocation() throws HeadlessException {
		    final Toolkit toolkit = Toolkit.getDefaultToolkit();
		    final Dimension screenSize = toolkit.getScreenSize();
		    final int x = (screenSize.width - frame1.getWidth()) / 2;
		    final int y = (screenSize.height - frame1.getHeight()) / 2;
		    frame1.setLocation(x, y);
		    frame1.setLocationRelativeTo(null);
		}
}
