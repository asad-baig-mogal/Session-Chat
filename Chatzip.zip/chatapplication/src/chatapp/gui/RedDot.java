package chatapp.gui;

import javax.swing.JTabbedPane;

import chatapp.backend.Chat1;

public class RedDot extends Thread {
   public static long glyphtime;
   JTabbedPane jTabbedPane1;
   Chat1 obj1;
   static int tempo=0;
	public JTabbedPane getjTabbedPane1() {
	return jTabbedPane1;
}

public void setjTabbedPane1(JTabbedPane jTabbedPane1) {
	this.jTabbedPane1 = jTabbedPane1;
}

public Chat1 getObj() {
	return obj1;
}

public void setObj(Chat1 obj1) {
	this.obj1 = obj1;
}

public static long getGlyphtime() {
	return glyphtime;
}

	public void run()
	{
		while(true)
		{
		boolean flag=obj1.queryImage(glyphtime);
        int codepoint=Integer.parseInt("U+1F534".substring(2),16);
        if(flag == true && tempo == 1)
        {
        	jTabbedPane1.setTitleAt(3,new StringBuilder().appendCodePoint(codepoint).toString()+" Images Window");
        }
        else
        {
        	jTabbedPane1.setTitleAt(3, "Images Window");
        	tempo=1;
        }
        try {
        	Thread.sleep(600);
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
		}
	}
	
	public static void setGlyphtime(long glyphtime1)
	{
		glyphtime=glyphtime1;
	}
}
