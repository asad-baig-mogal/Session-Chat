package chatapp.backend;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import javax.swing.DefaultListModel;
import javax.swing.JList;


public class Participants implements Runnable{
	String url="jdbc:mysql://localhost:3306/chatapp";
    String user="root";
    String pass="Nowheerabegum@123";
     String namestable;
 	 long nametime;
 	 String admin="";
 	 String name="";
 	 static int flag=0;
 	 public ArrayList<Object> lin=new ArrayList<Object>();
 	 public JList<Object> list;
 	public boolean flag1;
	 public Participants(String namestable,long nametime,String name,String admin,JList<Object> list)
 	 {
 		 this.namestable=namestable;
 		 this.nametime=nametime;
 		 this.admin=admin;
 		 this.name=name;
 		 this.list=list;
 	 }
	 
	 public void getParticipants()
		{

		 try
		 {
			Connection  con = DriverManager.getConnection(url,user,pass);
			Statement st=con.createStatement();
			String quer="select participants from "+namestable+" where milli>="+nametime;
			ResultSet res=st.executeQuery(quer);
			String temp="";
			while(res.next())
			{
				if(flag==0)
				{
					lin.add("PARTICIPANTS");
					flag=1;
				}
				temp=res.getString(1);
				lin.add(">> "+temp);
			}
			 DefaultListModel<Object> listModel = new DefaultListModel<Object>();
			 for (int i = 0; i < lin.size(); i++)
			 {
			     listModel.addElement(lin.get(i));
			 }
			 list.setModel(listModel);
			 list.revalidate();
		       list.repaint();
			lin.clear();

			//lin.add("Code: "+namestable.substring(0,namestable.length()-5));
			lin.add("PARTICIPANTS");
	        
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		}
	 public void run() {
			while(true)
			{
			 getParticipants();
			 try
			 {
			   Thread.sleep(600);
			 }
			 catch(Exception e)
			 {
				 e.printStackTrace();
			 }
			}
			
		}
}
