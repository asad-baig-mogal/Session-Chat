package chatapp.backend;

import java.sql.*;

public class SecretCodeStore {

	public boolean storekey(String s)
	  {
	      Connection con=null;
	      String url="jdbc:mysql://localhost:3306/chatapp";
	      String user="root";

	      String pass="Nowheerabegum@123";
	      String sql="insert into codestore values('"+s+"')";
	      
	    try
	    {
	        
	        con = DriverManager.getConnection(url,user,pass);

	        Statement st = con.createStatement();

	        int m = st.executeUpdate(sql);
	        if (m == 1)
	        {
	            con.close();
	            return true;
	        }
	        else
	        {
	            con.close();
	            return false;
	        }
	      
	    }
	    catch(Exception ex)
	    {
	        System.err.println(ex);
	    }
	      return true;
	  }  
}
