package chatapp.backend;

import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;

import chatapp.gui.ChatWindow3;

public class Chat1 implements Runnable{
	
	String messagetable;
	long msgtime;
	public ArrayList<Object> lin=new ArrayList<Object>();
 	public JList<Object> list;
 	public JList<Object> imageList;
 	static public boolean flag=true;
 	JScrollBar  bar;
	public Chat1(JList<Object> list,String messagetable,long msgtime,JList<Object> imageList)
	{
		this.list=list;
		this.messagetable=messagetable;
		this.msgtime=msgtime;
		this.imageList = imageList;
	}

	@Override
	public void run() {
		while(true)
		{
		 getMessages();
		
		 try
		 {
		   Thread.sleep(600);
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		}
		
	}

	public void getMessages() {
		
		  String url="jdbc:mysql://localhost:3306/chatapp";
	      String user="root";
	      String pass="Nowheerabegum@123";
	      String query="";
//	   n   String query2="";
//	   n   String table=messagetable+"image";
		    
	      try
	      {
	    	  Connection con=DriverManager.getConnection(url,user,pass);
			  Statement st=con.createStatement();
			  query="select * from "+messagetable+" where milli>="+msgtime;
//		n	  query2="select * from "+table+" where time>="+msgtime;
			  ResultSet res=st.executeQuery(query);
			 
			  String s="";
			  
			
				while(res.next())
				{
					 //s="<html> &gt&gt  <br><b>"+res.getString(3)+"</b>:  <br>"+res.getString(2)+"<br><br></html>";
				//s=">> "+res.getString(3)+":  "+res.getString(2);
					//lin.add(">> "+res.getString(3));
					//lin.add(res.getString(2));
					
					  lin.add(">> "+res.getString(3)+" : ");
					  lin.add("    "+res.getString(2));
					  lin.add("\n");
					  
					 
				//lin.add(s);
					
				}
				
				res.close();
//		n		 ResultSet res2=st.executeQuery(query2);
//		n		ArrayList<Object> arr=new ArrayList<>();
//		n		//ArrayList<ImageIcon> arr1=new ArrayList<>();
//		n		byte[] image=null;
//		n		while(res2.next())
//		n		{
//		n			image=res2.getBytes(1);
//		n			image=scaleBytes(image,100,100);
//		n			arr.add(">> "+res2.getString(2)+" : ");
//		n			arr.add(new ImageIcon(image));
//		n			arr.add("\n");
//		n		}
//		n		res2.close();
				
				 DefaultListModel<Object> listModel = new DefaultListModel<Object>();
				 for (int i = 0; i < lin.size(); i++)
				 {
				     listModel.addElement(lin.get(i));
				 }
//		n		 for(int i=0;i<arr.size();i++)
//		n		 {
//		n			 listModel.addElement(arr.get(i));
//		n		 }
				 list.setModel(listModel);
				 
				 list.revalidate();
			     list.repaint();
			     int lastIndex = list.getModel().getSize() - 1;
				 if (lastIndex >= 0) {
				    list.ensureIndexIsVisible(lastIndex);
				 }
				 
			     lin.clear();
			    // arr.clear();
			     
//				 
//				list.setFixedCellWidth(300);
//			 
     			//list.setCellRenderer(new MyCellRenderer());
//				list.setBackground(new Color(215,255,255));
//				list.setForeground(Color.BLACK);
//			    list.setFont(new Font("Monospaced",Font.BOLD,15));
//			    panel1.removeAll();
//			    UIManager.put("ScrollBar.width",6);
//			    pane1=new JScrollPane(list);
//			  
//			    Dimension d=new Dimension(300,600);
//			    pane1.setPreferredSize(d);
//			    panel1.add(pane1);
//			    panel1.revalidate();
//			    panel1.repaint();
			   
			    
                   //bar=pane1.getVerticalScrollBar();
//				    bar.setValue(bar.getMaximum());
				
			    
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();  
	    	  ChatWindow3 obj = new ChatWindow3();
	    	  obj.disposeFrame();
	    	  JFrame close=new JFrame("Session Chat");
	    	  close.setLocationRelativeTo(null);
	   	      close.setResizable(false);
	   	      close.setIconImage(Toolkit.getDefaultToolkit().getImage("d:/sessionchat/gui/OIP.jpg"));
	   	      close.setBackground(Color.white);
	   	      JOptionPane.showMessageDialog(close,"chat session has been ended by the host");
	   	      close.setVisible(true);
	   	      close.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    	  System.exit(0);
	    	 
	      }
		
	}
	

	public void getImages()
	{
		  String url="jdbc:mysql://localhost:3306/chatapp";
	      String user="root";
	      String pass="Nowheerabegum@123";
	      String query2="";
	      String table=messagetable+"image";
	      
	      try
	      {
	    	  Connection con=DriverManager.getConnection(url,user,pass);
			  Statement st=con.createStatement();
			  query2="select * from "+table+" where time>="+msgtime;
			  ResultSet res2=st.executeQuery(query2);
				ArrayList<Object> arr=new ArrayList<>();
				//ArrayList<ImageIcon> arr1=new ArrayList<>();
				byte[] image=null;
				while(res2.next())
				{
					image=res2.getBytes(1);
					image=scaleBytes(image,180,160);
					arr.add(">> "+res2.getString(2)+" : ");
					arr.add(new ImageIcon(image));
					arr.add("\n");
				}
				res2.close();
				DefaultListModel<Object> listModel = new DefaultListModel<Object>();
				for(int i=0;i<arr.size();i++)
				 {
					 listModel.addElement(arr.get(i));
					 
				 }
			  imageList.setModel(listModel);
			  int lastIndex = list.getModel().getSize() - 1;
				 if (lastIndex >= 0) {
				    list.ensureIndexIsVisible(lastIndex);
				 }
				 
				 arr.clear();
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
	      }
	}
	
	
	
	  public static byte[] scaleBytes(byte[] fileData, int width, int height) {
		  ByteArrayInputStream byteInStream = new ByteArrayInputStream(fileData);
		  ByteArrayOutputStream byteOutStream=null;
		  try {
			  BufferedImage img = ImageIO.read(byteInStream);
			  if(height == 0)
			  {
				height = (width * img.getHeight())/img.getWidth();  
			  }
			  
			  if(width == 0)
			  {
				  width = (height *img.getWidth())/img.getHeight();
			  }
			  
			  Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
			  BufferedImage imageBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			  imageBuffer.getGraphics().drawImage(scaledImage,0,0, new Color(0,0,0) , null);
			  
			  byteOutStream = new ByteArrayOutputStream();
			  ImageIO.write(imageBuffer, "jpg", byteOutStream);
			  
			  
		  }
		  catch(Exception e)
		  {
			  e.printStackTrace();
		  }
		  
		  return byteOutStream.toByteArray();
	  }
	  
	  
	  public boolean queryImage(long glyphtime)
	  {
		  String url="jdbc:mysql://localhost:3306/chatapp";
	      String user="root";
	      String pass="Nowheerabegum@123";
	      String query2="";
	      String table=messagetable+"image";
	      int count=0;
	      
	      try
	      {
	    	  Connection con=DriverManager.getConnection(url,user,pass);
			  Statement st=con.createStatement();
			  query2="select count(*) from "+table+" where time>="+glyphtime;
			  ResultSet res2=st.executeQuery(query2);
			  while(res2.next())
				{
					count=res2.getInt(1);
				}
			  if(count > 0)
			  {
				  return true;
			  }
	      }
	      catch(Exception e)
	      {
	    	  e.printStackTrace();
	      }
		  return false;
	  }

}




//@SuppressWarnings("rawtypes")
//class MyCellRenderer extends DefaultListCellRenderer implements ListCellRenderer<Object> {
//
//	@SuppressWarnings("unused")
//	private static final long serialVersionUID = 1L;
//	 
//	
//
//	@Override
//	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
//	{
//		String s=value.toString();
//		int length=s.length();
//		int rows=0;
//		rows=(length/30)+2;
//		JTextArea renderer = new JTextArea(rows,30);
//		
//		renderer.setFont(new Font("Monospaced",Font.BOLD,15));
//		renderer.setBackground(Color.WHITE);
//		renderer.setText(s);
//		renderer.setLineWrap(true);
//		renderer.setWrapStyleWord(true);
//		return renderer;
//	}
//   
//	}
