package chatapp;

import chatapp.gui.*;


public class Main {

	public static void main(String[] args) {
		 new StartWindow();   
	}

}
